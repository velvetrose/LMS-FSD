import React from 'react';

const Ucam = () => {
    return (
        <div>
            <h2>This page is comming soon...</h2>
        </div>
    );
};

export default Ucam;