export const SET__USER='SET__USER'
export const CLEAR__USER='CLEAR__USER'
