This is my University LMS clone.<br>

<h3>Features:</h3><br>

1.Role base authentication<br>
2.Admin can post courses.<br>
3.Admin can delete courses.<br>
4.Admin handle teacher and student all things.<br>
5.Student can see profile.<br>
6.Student can see all courses.<br>
7.Teacher can see his/her profile.<br>
8.Teacher can see All courses.<br>
9.Student can see all courses info.<br>
10. Pagination, Route protection etc.<br>

<h3>Technology: </h3/><br>

1.Reactjs <br>
2.Nodejs.<br>
3.Express js<br>
4.MongoDB<br>
5.Heroku Hosting<br>
6.Material UI<br>
7. React BootStrap<br>
8.Module CSS<br>
9.Redux, React-Redux<br>
10.Multer and Cloudinary For photo upload<br>

<h4>Demo Link: https://lms--71.herokuapp.com/<h4/>
